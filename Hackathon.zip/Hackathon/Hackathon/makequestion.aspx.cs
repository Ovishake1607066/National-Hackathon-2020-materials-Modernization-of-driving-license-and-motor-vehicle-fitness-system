﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace Hackathon
{
    public partial class makequestion : System.Web.UI.Page
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "Jtit8bF6dZqDFmoWSi7K8wycjEyKzEo7vq8muQf2",
            BasePath = "https://autolicense-1d6f2.firebaseio.com/"
        };
        IFirebaseClient client;
        protected void Page_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);
            if (client != null)
            {
               // Response.Write("Connection established");
            }
        }

        protected async void Button1_Click(object sender, EventArgs e)
        {
            var data = new Data
            {
                ans=TextBox1.Text,
                op1=TextBox2.Text,
                op2=TextBox3.Text,
                op3=TextBox4.Text,
                op4=TextBox5.Text,
                ques=TextBox6.Text
            };
            SetResponse response = await client.SetTaskAsync("Question/" + TextBox7.Text, data);
            Data result = response.ResultAs<Data>();
            Response.Write(result.ques);
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("request.aspx");
        }
    }
}