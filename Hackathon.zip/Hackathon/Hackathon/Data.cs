﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hackathon
{
    class Data
    {
        public String ans { get; set; }
        public String op1 { get; set; }
        public String op2 { get; set; }
        public String op3 { get; set; }
        public String op4 { get; set; }
        public String ques { get; set; }
        public String Fullname { get; set; }
        public String CarModel { get; set; }
        public String Birthdate { get; set; }
        public String NID_NO { get; set; }
        public String uid { get; set; }
        public String ImageOfFace { get; set; }
    }
}
