﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Data;

namespace Hackathon
{
    public partial class request : System.Web.UI.Page
    {
        DataTable dt = new DataTable();
       
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "Jtit8bF6dZqDFmoWSi7K8wycjEyKzEo7vq8muQf2",
            BasePath = "https://autolicense-1d6f2.firebaseio.com/"
        };
        IFirebaseClient client;
        protected async void Page_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);
            if (client != null)
            {
                //Response.Write("Connection established");
            }
            int i = 0;
            dt.Columns.Add("Name");
            dt.Columns.Add("NID");
            dt.Columns.Add("Model");
            dt.Columns.Add("Date of Birth");
            dt.Columns.Add("UID");
            dt.Columns.Add("Face");
            FirebaseResponse res = await client.GetTaskAsync("Customers/1j5eNV1sQVNMSY3fTV1BhEHrph22");
            Data obj = res.ResultAs<Data>();
            DataRow r = dt.NewRow();
            r["Name"] = obj.Fullname;
            r["NID"] = obj.NID_NO;
            r["Model"] = obj.CarModel;
            r["Date of Birth"] = obj.Birthdate;
            r["UID"] = obj.uid;
            r["Face"] = obj.ImageOfFace;
            dt.Rows.Add(r);
            //this.GridView1.Visible = true;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("request.aspx");
        }
    }
}