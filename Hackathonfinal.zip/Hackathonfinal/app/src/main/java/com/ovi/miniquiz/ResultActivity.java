package com.ovi.miniquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity  {
    TextView textView2,textView4,textView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        textView2  = findViewById(R.id.textView2);
        textView4  = findViewById(R.id.textView4);
        textView6  = findViewById(R.id.textView6);
        Intent i = getIntent();
        String questions  = i.getStringExtra("Total");
        String correct  = i.getStringExtra("Correct");
        String wrong  = i.getStringExtra("Incorrect");
        textView2.setText(questions);
        textView4.setText(correct);
        textView6.setText(wrong);

    }

}
